import './App.css';
import IDPW from './HW/IDPW.js'
import Scroll_section from './HW/Scroll_section.js' 

const App = () => {
  return <Scroll_section />;   
}

export default App;
